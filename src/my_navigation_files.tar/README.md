# The my_navigation_files package


## Description

This package is required for the Docker course.  
It represents a custom made package with launch, configuration and map files for running ROS Navigation inside a Docker container.  


This package has to be copied inside a Dockerfile / Docker container as instructed by the course.  
